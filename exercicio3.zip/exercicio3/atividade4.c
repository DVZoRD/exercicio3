#include<stdio.h>
#include<math.h>

main(){
    int x , y = 60;

printf("Quanto vc pesa?");
scanf("%d" , &x);

if(x > y){

    printf("Vc tem mais que 60kg");};

    if(x=y){
        printf("Vc tem 60 kg");
    }
else{
    printf("Vc tem menos de 60kg");
}
}
