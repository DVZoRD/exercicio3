#include<stdio.h>
#include<math.h>

main(){

int x , y = 1302;

printf("Quanto vc ganha?");
scanf("%d" , &x);

if(x > y){

    printf("Seu salario e maior que o minimo");}

else{
    printf("Seu salario e menor que o minimo");
}


}