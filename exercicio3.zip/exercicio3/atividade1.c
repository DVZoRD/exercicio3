#include<stdio.h>
#include<math.h>

main(){

int x , y = 18;

printf("Qual e a sua idade?");
scanf("%d" , &x);

if(x >= y){

    printf("Vc e maior de idade");}

else{
    printf("Vc e menor de idade");
}







}